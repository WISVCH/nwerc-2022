Name: Your name
Email: your@email.address

Relevant experience:
- e.g. BAPC participant in year
- also coach/organiser/jury/... roles
